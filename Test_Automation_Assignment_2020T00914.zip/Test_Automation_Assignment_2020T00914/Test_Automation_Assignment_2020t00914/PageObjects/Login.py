from selenium.webdriver.common.by import By

class Login:
    def __init__(self, driver):
        self.driver = driver
        # Define locators for username, password and login button
        self.username_field = (By.NAME, "username")
        self.password_field = (By.NAME, "password")
        self.login_btn = (By.XPATH, '//*[@id="app"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[3]/button')

    def input_username(self, username):
        # Input username into username field
        self.driver.find_element(*self.username_field).send_keys(username)

    def input_password(self, password):
        # Input password into password field
        self.driver.find_element(*self.password_field).send_keys(password)

    def click_login(self):
        # Click the login button
        self.driver.find_element(*self.login_btn).click()

    def login(self, username, password):
        # Perform login by filling credentials and clicking login
        self.input_username(username)
        self.input_password(password)
        self.click_login()