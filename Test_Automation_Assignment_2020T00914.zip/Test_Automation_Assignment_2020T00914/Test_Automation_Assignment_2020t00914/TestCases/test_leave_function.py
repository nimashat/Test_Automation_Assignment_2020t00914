import time
from selenium import webdriver
from PageObjects.Login import Login
from PageObjects.Dashboard import Dashboard
from PageObjects.Leave import Leave

class Test_leave_fuction:
    base_url = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"
    username = "Admin"
    password = "admin123"

    def test_leave_function(self):
        # Start browser session
        driver = webdriver.Chrome()
        driver.maximize_window()
        driver.get(self.base_url)
        time.sleep(5)

        # Login to the system
        login = Login(driver)
        login.login(self.username, self.password)
        time.sleep(5)

        # Navigate to My Leave section
        dashboard = Dashboard(driver)
        dashboard.my_leave_function_test()
        time.sleep(5)

        # Check if leave page is loaded
        leave = Leave(driver)
        if leave.is_leave_page_displayed():
            assert True
            print("Leave page displayed: Test Passed")
        else:
            assert False
            print("Leave page not displayed: Test Failed")

        driver.quit()
