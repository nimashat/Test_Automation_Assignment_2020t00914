import time
from selenium import webdriver
from PageObjects.Login import Login
from PageObjects.Dashboard import Dashboard

class Test_Logout:
    base_url = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"
    username = "Admin"
    password = "admin123"

    def test_logout_function(self):
        # Launch the browser and login
        driver = webdriver.Chrome()
        driver.maximize_window()
        driver.get(self.base_url)
        time.sleep(2)

        login = Login(driver)
        login.login(self.username, self.password)
        time.sleep(3)

        # Perform logout
        dashboard = Dashboard(driver)
        dashboard.logout_profile()
        time.sleep(2)

        # Verify if logout was successful (URL contains 'login')
        current_url = driver.current_url
        if "login" in current_url:
            assert True
            print("Logout successful: Test Passed")
        else:
            assert False
            print("Logout failed: Test Failed")

