import time
from selenium import webdriver
from PageObjects.Login import Login
from PageObjects.Dashboard import Dashboard

class Test_Login_function:
    base_url = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"
    username = "Admin"
    password = "admin123"

    def test_login(self):
        # Initialize browser
        driver = webdriver.Chrome()
        driver.maximize_window()
        driver.get(self.base_url)
        time.sleep(5)

        # Login with provided credentials
        login = Login(driver)
        login.login(self.username, self.password)
        time.sleep(5)

        # Verify dashboard is displayed
        dashboard = Dashboard(driver)
        if dashboard.dashboard_function_test():
            assert True
            print("Dashboard displayed: Test Passed")
        else:
            assert False
            print("Dashboard not displayed: Test Failed")

        driver.quit()